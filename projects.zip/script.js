// Atrod elementus dokumentā
const poga = document.getElementById('poga-aprekinat');
const rezultats = document.getElementById('rezultata-vieta');

// Funkcija, kas veic aprēķinu
function darbaProcess() {
    // Nolasa vērtības
    let skaits = document.getElementById('ievade-daudzums').value;
    let cena = document.getElementById('produkta-izvele').value;

    // Pārbauda, vai lauks nav tukšs
    if (skaits === "" || skaits <= 0) {
        rezultats.textContent = "Lūdzu, ievadi skaitli!";
        rezultats.style.color = "red";
    } else {
        let kopa = skaits * cena;
        // Parāda rezultātu HTML dokumentā
        rezultats.textContent = "Kopā jāmaksā: " + kopa.toFixed(2) + " €";
        rezultats.style.color = "black";
    }
}

// Pievieno klikšķa notikumu
poga.addEventListener('click', darbaProcess);