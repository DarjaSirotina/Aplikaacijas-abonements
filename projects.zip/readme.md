# Mājas darbs: Produkta kalkulators

## Apraksts
Šī ir vienkārša mājaslapa, kas aprēķina pirkuma summu. Izmantots HTML struktūrai, CSS dizainam un JavaScript funkcionalitātei.

## Izmantotās tehnoloģijas
- **HTML**: id un klases, ievades lauki, pogas.
- **CSS**: fona krāsa, teksta stili, rāmīša novietojums.
- **JS**: mainīgie (let, const), funkcija, notikumu klausītājs.

## Kā lietot?
Ieraksti daudzumu lodziņā, izvēlies preci un spied pogu "Aprēķināt".